<?php

declare(strict_types=1);

// This file is used to store local admin credentials.
// It should NOT be committed to version control.
// For production, use environment variables.

define('SFM_ADMIN_USERNAME', 'Stalyn45');
define('SFM_ADMIN_PASSWORD', 'Amor1980!');
