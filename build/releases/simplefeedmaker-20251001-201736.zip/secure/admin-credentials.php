<?php

declare(strict_types=1);

/**
 * Admin credentials for SimpleFeedMaker
 *
 * Generated password hash built with:
 *   php secure/scripts/hash_password.php 'Amor1980!'
 */

define('ADMIN_USERNAME', 'Stalyn45');

define('ADMIN_PASSWORD_HASH', '$2y$10$UiEETq.psrYcDU0iH/EKye6OmDkjzD095dUeCXUFmMLfgZUjWaQ1m');

// Legacy fallbacks (leave blank if not used)
if (!defined('ADMIN_PASSWORD')) {
    define('ADMIN_PASSWORD', '');
}
if (!defined('SFM_ADMIN_USERNAME')) {
    define('SFM_ADMIN_USERNAME', ADMIN_USERNAME);
}
if (!defined('SFM_ADMIN_PASSWORD')) {
    define('SFM_ADMIN_PASSWORD', ADMIN_PASSWORD);
}
